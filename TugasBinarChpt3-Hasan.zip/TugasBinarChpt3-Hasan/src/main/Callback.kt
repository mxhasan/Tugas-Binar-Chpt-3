interface CallBack {
    fun munculkanHasilnya (msg:String)
}